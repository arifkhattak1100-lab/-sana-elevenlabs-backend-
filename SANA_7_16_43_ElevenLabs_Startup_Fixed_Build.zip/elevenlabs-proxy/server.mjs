import express from "express";
const app = express();
app.use(express.json({limit:"32kb"}));
const PORT = Number(process.env.PORT || 8787);
const API_KEY = process.env.ELEVENLABS_API_KEY || "";
const DEFAULT_VOICE_ID = process.env.ELEVENLABS_VOICE_ID || "";
const MODEL_ID = process.env.ELEVENLABS_MODEL_ID || "";

app.get("/health", (_req,res) => res.json({
  ok:true, provider:"elevenlabs-proxy",
  keyConfigured:Boolean(API_KEY), voiceConfigured:Boolean(DEFAULT_VOICE_ID),
  modelConfigured:Boolean(MODEL_ID)
}));

app.post("/api/elevenlabs/tts", async (req,res) => {
  if(!API_KEY) return res.status(503).json({error:"Server is missing ELEVENLABS_API_KEY."});
  if(!MODEL_ID) return res.status(503).json({error:"Server is missing ELEVENLABS_MODEL_ID. Set a model that your account confirms supports Urdu."});
  const voiceId=String(req.body?.voiceId || DEFAULT_VOICE_ID).trim();
  const text=String(req.body?.text || "").trim().slice(0,1200);
  if(!voiceId) return res.status(400).json({error:"A verified ElevenLabs Voice ID is required."});
  if(!text) return res.status(400).json({error:"Text is required."});
  try {
    const upstream=await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}`,{
      method:"POST",
      headers:{"xi-api-key":API_KEY,"content-type":"application/json","accept":"audio/mpeg"},
      body:JSON.stringify({text,model_id:MODEL_ID,voice_settings:{stability:0.55,similarity_boost:0.78}})
    });
    if(!upstream.ok){
      const detail=await upstream.text();
      return res.status(upstream.status).json({error:"ElevenLabs rejected the request.",detail:detail.slice(0,2000)});
    }
    const bytes=Buffer.from(await upstream.arrayBuffer());
    if(!bytes.length) return res.status(502).json({error:"ElevenLabs returned empty audio."});
    res.setHeader("content-type",upstream.headers.get("content-type")||"audio/mpeg");
    res.setHeader("cache-control","no-store");
    res.send(bytes);
  } catch(e) {
    res.status(502).json({error:"Could not reach ElevenLabs.",detail:String(e.message||e)});
  }
});
app.listen(PORT,"0.0.0.0",()=>console.log(`SANA ElevenLabs proxy listening on ${PORT}`));
